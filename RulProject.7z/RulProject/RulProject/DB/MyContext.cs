﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RulProject.MyForms;

namespace RulProject.DB
{
    public class MyContext : DbContext
    {
        private string cs = "Server=192.168.10.160;database=TestDbAddUser_Rakhmetov;user id=stud;password=stud";

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(cs);
        }
        public DbSet<UserPR> users { get; set; }
        public DbSet<ProductPR> productPRs { get; set; }
    }
}

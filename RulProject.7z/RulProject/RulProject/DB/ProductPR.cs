﻿using System.ComponentModel.DataAnnotations;

namespace RulProject.DB
{
    public class ProductPR
    {
        [Key]
        public int ProductPrId { get; set; }
        public string Foto { get; set; }
        public string Proizvod { get; set; }
        public int Price { get; set; }
        public string PriceString { get; set; }
        public int PriceSale { get; set; }
        public string PriceSaleString { get; set; }
        public string MinSale { get; set; }
        public string Coment { get;set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RulProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        /// <summary>
        /// авторизация для пользователей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void BtnGo_Click(object sender, RoutedEventArgs e)
        {
            DB.UserPR user = null;
            try 
            { 
                DB.MyContext myContext = new DB.MyContext();
                 user = myContext.users.SingleOrDefault(x => x.Login == tbLogin.Text && x.Password == TbPassword.Text);
                if(user == null)
                {
                    MessageBox.Show("User not found");
                    return;
                }
                else
                {
                    MessageBox.Show("User found");
                }
            
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            if(user.Status == "admin")
            {
                MyForms.AdminWindows adminWindows = new MyForms.AdminWindows(user);
                adminWindows.Show();
                Close();
                return;

            }
            if(user.Status == "user")
            {
                MyForms.UserWindows userWindows = new MyForms.UserWindows(user);
                userWindows.Show();
                Close();
                return;
            }
            if (user.Status == "manager")
            {
                MyForms.ManagerWindows managerWindows = new MyForms.ManagerWindows(user);
                managerWindows.Show();
                Close();
                return;
            }
        }
       /// <summary>
       /// авторизация для гостя
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
        private void btnGuestGo_Click(object sender, RoutedEventArgs e)
        {
            MyForms.GuestWindows guestWindows = new MyForms.GuestWindows();
            guestWindows.Show();
            Close();
        }
    }
}
